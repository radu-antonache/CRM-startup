﻿using System;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace CustomWorkflowActivity
{
    // https://docs.microsoft.com/en-us/powerapps/developer/common-data-service/workflow/workflow-extensions
    // Install-Package Microsoft.CrmSdk.Workflow -Version 9.0.2.26
    public class IncrementByTen : CodeActivity
    {
        [RequiredArgument]
        [Input("Decimal input")]
        public InArgument<decimal> DecInput { get; set; }

        [Output("Decimal output")]
        public OutArgument<decimal> DecOutput { get; set; }

        [Input("Int input")]
        [Output("Int output")]
        public InOutArgument<int> IntParameter { get; set; }

        [Input("Bool input")]
        [Default("True")]
        public InArgument<bool> Bool { get; set; }

        [Input("EntityReference input")]
        [Output("EntityReference output")]
        [ReferenceTarget("account")]
        public InOutArgument<EntityReference> AccountReference { get; set; }

        [Input("Account IndustryCode value")]
        [AttributeTarget("account", "industrycode")]
        [Default("3")]
        public InArgument<OptionSetValue> IndustryCode { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            decimal input = DecInput.Get(context);
            DecOutput.Set(context, input + 10);

            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();

            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            // Use the context service to create an instance of IOrganizationService.             
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.InitiatingUserId);

            //Create the tracing service
            ITracingService tracingService = context.GetExtension<ITracingService>();

            //Use the tracing service
            tracingService.Trace("{0} {1} {2}.", "Add", "your", "message");

        }
    }
}
