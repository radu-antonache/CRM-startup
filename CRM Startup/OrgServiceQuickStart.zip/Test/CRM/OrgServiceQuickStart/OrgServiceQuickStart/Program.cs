﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using System;

namespace OrgServiceQuickStart
{
    class Program
    {
        static void Main(string[] args)
        {
            // e.g. https://yourorg.crm.dynamics.com
            string url = "https://xrafsoft.crm4.dynamics.com";
            // e.g. you@yourorg.onmicrosoft.com
            string userName = "radu.antonache@xrafsoft.onmicrosoft.com";
            // e.g. y0urp455w0rd 
            string password = "Travel01.";

            string conn = $@"
                Url = {url};
                AuthType = Office365;
                UserName = {userName};
                Password = {password};
                RequireNewInstance = True";

            using (var svc = new CrmServiceClient(conn))
            {

                WhoAmIRequest request = new WhoAmIRequest();

                WhoAmIResponse response = (WhoAmIResponse)svc.Execute(request);

                Console.WriteLine("Your UserId is {0}", response.UserId);

                Console.WriteLine("Press any key to exit.");
                Console.ReadLine();
            }
        }
    }
}
